from __future__ import annotations

from .cli import main as cli_main


def main() -> None:
    cli_main()


if __name__ == "__main__":
    main()
